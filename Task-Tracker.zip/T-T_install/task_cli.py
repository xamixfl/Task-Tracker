import json
from datetime import datetime
import sys

def main():
    if len(sys.argv) < 2:
        print("Некорректный запуск. Использование: python 1.py <название команды> \
<аргумент2(если необходимо)> <аргумент3(если необходимо)>")
    elif sys.argv[1] == 'add':
        if len(sys.argv) == 2:
            print("Использование: python task_cli.py add <название задачи>")
        else:
            name = ""
            for word in sys.argv[2:]:
                name += word + " "
            name = name.strip()
            adding(name)
    elif sys.argv[1] == 'update':
        if len(sys.argv) == 2:
            print("Использование: python task_cli.py update <идентификатор задачи> <новое название>")
        else:
            name = ""
            for word in sys.argv[3:]:
                name += word + " "
            name = name.strip()
            updating(sys.argv[2], name)
    elif sys.argv[1] == 'delete':
        if len(sys.argv) != 3:
            print("Использование: python task_cli.py delete <идентификатор задачи>")
        else:
            deletion(sys.argv[2])
    elif sys.argv[1] == 'mark-in-progress':
        if len(sys.argv) != 3:
            print("Использование: python task_cli.py mark-in-progress <идентификатор задачи>")
        else:
            mark_in_progress(sys.argv[2])
    elif sys.argv[1] == 'mark-done':
        if len(sys.argv) != 3:
            print("Использование: python task_cli.py mark-done <идентификатор задачи>")
        else:
            mark_done(sys.argv[2])
    elif sys.argv[1] == 'list':
        if len(sys.argv) == 2:
            show_list()
        else:
            if sys.argv[2] == 'done':
                show_done()
            elif sys.argv[2] == 'todo':
                show_todo()
            elif sys.argv[2] == 'in-progress':
                show_in_progress()
            else:
                print("Аргумент не найден. Введите пожалуйста действительные параметры.")
    else:
        print("Использование: python task_cli.py <название команды> <аргумент2(если необходимо)> <аргумент3(если необходимо)>")


def adding(task_name):                                                     # Добавление задачи
    with open('data.json', 'r', encoding='utf-8') as file:
        data = json.load(file)
        if data['tasks'] == {}:
            num = 1
        else:
            keys = list(data['tasks'].keys())
            key_num = keys[-1]
            num = data['tasks'][key_num]['id'] + 1

        desc = str(input("Enter a description of the task: "))
        time_task = datetime.now()
        formatted_time = time_task.strftime("%Y-%m-%d %H:%M")

        data['tasks'][task_name] = {
        "id": num,
        "description": f"{desc}",
        "status": "todo",
        "createdAt": f"{formatted_time}",
        "updatedAt": f"{formatted_time}"
    }
    with open('data.json', 'w', encoding='utf-8') as file:
        json.dump(data, file, ensure_ascii=False, indent=4)
    print(f"Task added successfully (ID: {num})")

def updating(id, new_name):                                              # Обновление задачи
    with open('data.json', 'r', encoding='utf-8') as file:
        data = json.load(file)

    time_task_upd = datetime.now()
    formatted_time_upd = time_task_upd.strftime("%Y-%m-%d %H:%M")

    key_upd = ""
    for key in data['tasks']:
        if data['tasks'][key]['id'] == int(id):
            key_upd = key

    if key_upd:

        agree = input("Хотите ли вы изменить описание этой задачи [Y/N]: ")
        while agree != "N" and agree != "Y":
                print("Нет такого варианта ответа. Попробуйте еще раз.")
                agree = input("Хотите ли вы изменить описание этой задачи [Y/N]: ")
        if agree == "Y":
            desc = str(input("Введите новое описание задачи: "))
        else:
            desc = data['tasks'][key_upd]['description']

        data['tasks'][new_name] = {
        "id": int(id) ,
        "description": desc,
        "status": data['tasks'][key_upd]['status'],
        "createdAt": data['tasks'][key_upd]["createdAt"],
        "updatedAt": formatted_time_upd
    }
        if key_upd != new_name:
            del data['tasks'][key_upd]
        with open('data.json', 'w', encoding='utf-8') as file:
            json.dump(data, file, ensure_ascii=False, indent=4)
        print("Task updated successfully.")
    else:
        print("Не существует задачи с заданным идентификатором.")


def deletion(id):                                                            # Удаление задачи
    with open('data.json', 'r', encoding='utf-8') as file:
        data = json.load(file)
    key_del = ""
    for key in data['tasks']:
        if data['tasks'][key]['id'] == int(id):
            key_del = key

    if key_del:
        del data['tasks'][key_del]
        with open('data.json', 'w', encoding='utf-8') as file:
            json.dump(data, file, ensure_ascii=False, indent=4)
        print("Task deleted successfully.")
    else:
        print("Не существует задачи с заданным идентификатором.")


def mark_in_progress(id):                                                # Отметить как "in-progress"    
    with open('data.json', 'r', encoding='utf-8') as file:
        data = json.load(file)
    key_mark = ""
    for key in data['tasks']:
        if data['tasks'][key]['id'] == int(id):
            key_mark = key
    data['tasks'][key_mark]['status'] = 'in-progress'
    with open('data.json', 'w', encoding='utf-8') as file:
        json.dump(data, file, ensure_ascii=False, indent=4)


def mark_done(id):                                                           # Отметить как "done"    
    with open('data.json', 'r', encoding='utf-8') as file:
        data = json.load(file)
    key_mark = ""
    for key in data['tasks']:
        if data['tasks'][key]['id'] == int(id):
            key_mark = key
    data['tasks'][key_mark]['status'] = 'done'
    with open('data.json', 'w', encoding='utf-8') as file:
        json.dump(data, file, ensure_ascii=False, indent=4)


def show_list():                                                            # Показать весь список задач
    with open('data.json', 'r', encoding='utf-8') as file:
        data = json.load(file)
    var = input("Вывести список задач с характеристиками? [Y/N]: ")
    while var != "N" and var != "Y":
        print("Нет такого варианта ответа. Попробуйте еще раз.")
        var = input("Вывести список задач с характеристиками? [Y/N]: ")
    if var == "Y":
        for key in data['tasks']:
            print(key)
            for char in data['tasks'][key]:
                print(f'{char}:', end=" ")
                print(data['tasks'][key][char])
    else:
        for key in data['tasks']:
            print(key)


def show_todo():                                                         # Показать только "todo"
    with open('data.json', 'r', encoding='utf-8') as file:
        data = json.load(file)
    var = input("Вывести список задач с характеристиками? [Y/N]: ")
    while var != "N" and var != "Y":
        print("Нет такого варианта ответа. Попробуйте еще раз.")
        var = input("Вывести список задач с характеристиками? [Y/N]: ")
    if var == "Y":
        for key in data['tasks']:
            if data['tasks'][key]['status'] == 'todo':
                print(key)
                for char in data['tasks'][key]:
                    print(f'{char}:', end=" ")
                    print(data['tasks'][key][char])
    else:
        for key in data['tasks']:
            if data['tasks'][key]['status'] == 'todo':
                print(key)


def show_in_progress():                                                   # Показать только "in-progress"
    with open('data.json', 'r', encoding='utf-8') as file:
        data = json.load(file)
    var = input("Вывести список задач с характеристиками? [Y/N]: ")
    while var != "N" and var != "Y":
        print("Нет такого варианта ответа. Попробуйте еще раз.")
        var = input("Вывести список задач с характеристиками? [Y/N]: ")
    if var == "Y":
        for key in data['tasks']:
            if data['tasks'][key]['status'] == 'in-progress':
                print(key)
                for char in data['tasks'][key]:
                    print(f'{char}:', end=" ")
                    print(data['tasks'][key][char])
    else:
        for key in data['tasks']:
            if data['tasks'][key]['status'] == 'in-progress':
                print(key)


def show_done():                                                          # Показать только "done"
    with open('data.json', 'r', encoding='utf-8') as file:
        data = json.load(file)
    var = input("Вывести список задач с характеристиками? [Y/N]: ")
    while var != "N" and var != "Y":
        print("Нет такого варианта ответа. Попробуйте еще раз.")
        var = input("Вывести список задач с характеристиками? [Y/N]: ")
    if var == "Y":
        for key in data['tasks']:
            if data['tasks'][key]['status'] == 'done':
                print(key)
                for char in data['tasks'][key]:
                    print(f'{char}:', end=" ")
                    print(data['tasks'][key][char])
    else:
        for key in data['tasks']:
            if data['tasks'][key]['status'] == 'done':
                print(key)



if __name__ == "__main__":
    main()



