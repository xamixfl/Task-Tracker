from setuptools import setup, find_packages

setup(
    name="Task Tracker",
    version="1.0.0",
    description="A CLI application to manage tasks.",
    author="Xamix",
    author_email="hxxxfl@gmail.com",
    py_modules=["task_cli"],
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "task-cli=programm_files.task_cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6"
)